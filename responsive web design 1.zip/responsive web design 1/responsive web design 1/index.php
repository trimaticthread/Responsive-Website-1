<?php 
require 'vendor/autoload.php';
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;
if(isset($_POST['submit_form'])){
    $_name = $_POST['name'];
    $_email = $_POST['email'];
    $_subject = $_POST['subject'];
    $_message = $_POST['message'];

    // Load Composer's autoloader




$mail = new PHPMailer(true);

try {
    //SMTP Server Settings
    $mail->SMTPDebug = 0; // DEBUG Kapalı: 0, DEBUG Açık: 2
    $mail->isSMTP();
    $mail->Host       = ''; // Email sunucu adresi.
    $mail->SMTPAuth   = true; // SMTP kullanici dogrulama kullan
    $mail->Username   = ''; // SMTP sunucuda tanimli email adresi
    $mail->Password   = ''; // SMTP email sifresi
    $mail->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS; // SSL icin `PHPMailer::ENCRYPTION_SMTPS` kullanin. SSL olmadan 587 portundan gönderim icin `PHPMailer::ENCRYPTION_STARTTLS` kullanin
    $mail->Port       = 465; // Eger yukaridaki deger `PHPMailer::ENCRYPTION_SMTPS` ise portu 465 olarak guncelleyin. Yoksa 587 olarak birakin
    $mail->setFrom('', 'M'); // Gonderen bilgileri yukaridaki $mail->Username ile aynı deger olmali

    //Alici Ayarları
    $mail->addAddress('m', 'Alıcı Ad Soyad'); // Alıcı bilgileri


    // İçerik
    $mail->isHTML(true); // Gönderimi HTML türde olsun istiyorsaniz TRUE ayarlayin. Düz yazı (Plain Text) icin FALSE kullanin
    $mail->CharSet = 'utf-8';
    $mail->Subject = 'Email Konusu';
    $mail->Body    = '    <style>
    body{
        background-color: aqua;
        color: white;
    }
</style>
<h1>Yeni Mesaj Alındı</h1>
<p>Ad: '.$_name.'</p><br>
<p>Mail: '.$_email.'</p><br>
<p>Konu: '.$_subject.'</p><br>
<p>Mesaj:<br>'.$_message.'</p><br>

';

    $mail->send();
    echo 'Tebrikler! Email başarıyla gönderildi!';
} catch (Exception $e) {
    echo "Ops! Email iletilemedi. Hata: {$mail->ErrorInfo}";
}

}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Toprak Güleç</title>
    <link rel="stylesheet" href="style.css">
    <link
    href="https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css"
    rel="stylesheet"/>
    <link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap" rel="stylesheet">
</head>

<body>
     
    <header class="header">
        <a href="#home" class="logo"> Name 
        <span>Surname</span></a>
       
        <i class="bx bx-menu" id="menu-icon"></i>
       
        <nav class="navbar">
          <a href="#home">Home</a>
            <a href="#about">About</a>
            <a href="#skills">Skills</a>
            <a href="#certifications">Certificates</a>
            <a href="#contact">Contact</a>
        </nav>
    </header>

    <!-- HOME -->

    <section class="home" id="home">
        <div class="home-content">
            <h1>lorem <span>lorem</span></h1>
            <h3>I'm <span>lorem ipsum dolor </span></h3>
            <p>
               Lorem ipsum dolor sit amet consectetur adipisicing elit. Numquam perferendis veniam sed ducimus incidunt quo ea aspernatur vitae recusandae eveniet tempore ullam deserunt ipsam quibusdam placeat amet deleniti, dolor sapiente!
            </p>
                 <div class="social-icons">
                    <a href="#">
                        <i class="bx bxl-github"></i>
                    </a>
                    <a href="#">
                        <i class="bx bxl-linkedin"></i>
                    </a>
                    <a href="#">
                        <i class="bx bxl-instagram"></i>
                    </a>
                </div>
        
                <div class="btn-group">
                    <a href="#add cv location" target="_blank" class="btn">Hire</a>
                    <a href="#contact" class="btn">Contact</a>
                </div>
                </div>
                
        <div class="home-img">
            <img src="#" alt="">
        </div>
   </section>


        <!-- ABOUT -->

        <section class="about" id="about">
            <div class="about-content">
                <h2>About Me</h2>
                <p>
                    Hello! I'm <b>lorem ipsum dolor </b>. Lorem, ipsum dolor sit amet consectetur adipisicing elit. Voluptates ex labore nam similique mollitia consequuntur a culpa, esse libero nobis, eius neque eveniet iusto itaque in officia quam praesentium illum!
                </p>
                <p>
                    Lorem ipsum dolor, sit amet consectetur adipisicing elit. Cupiditate fugit doloremque modi dolore necessitatibus quam sit quas eaque quae, impedit rerum in odit sint assumenda praesentium facere alias reiciendis consequatur!
                </p>
                <p>
                    Lorem ipsum dolor sit amet consectetur adipisicing elit. Debitis explicabo eveniet tempora, eius possimus optio alias dignissimos molestias ea, magnam est repellendus dolor itaque aspernatur eligendi. Quia, nam quibusdam! Architecto.
                </p>
            </div>
        </section>
        
        <!-- Skills -->

        <section class="skills" id="skills">
            <h2>Skills</h2>
            <div class="skills-container">
              <div class="skill">
                <h3>lorems</h3>
                <ul>
                    <li>lorem#</li>
                    <li>lorem</li>
                    <li>lorem</li>
                </ul>
              </div>
              <div class="skill">
                <h3>lorem</h3>
                <ul>
                    <li>lorem</li>
                    <li>lorem</li>
                </ul>
              </div>
             <div class="skill">
                <h3>lorem</h3>
                <ul>
                    <li>lorem</li>
                    <li>lorem</li>
                    <li>lorem</li>
                </ul>
             </div>
             <div class="skill">
                <h3>lorem</h3>
                <ul>
                    <li>lorem</li>
                    <li>lorem</li>
                    <li>lorem</li>
                    <li>lorem</li>
                    <li>lorem</li>
                </ul>
            </div>
        </div>
    
        <div class="skills-progress">
            <div class="progress-item">
                <span>lorem</span>
                <div class="progress-bar">
                    <div class="progress-fill" style="width: 80%;"></div>
                </div>
                <div class="progress-percent">80%</div>
            </div>
            <div class="progress-item">
                <span>lorem</span>
                <div class="progress-bar">
                    <div class="progress-fill" style="width: 70%;" ></div>
                </div>
                <div class="progress-percent">70%</div>
            </div>
            <div class="progress-item">
                <span>lorem</span>
                <div class="progress-bar">
                    <div class="progress-fill" style="width: 70%;"></div>
                </div>
                <div class="progress-percent">70%</div>
            </div>
            <div class="progress-item">
                <span>lorem</span>
                <div class="progress-bar">
                    <div class="progress-fill" style="width: 90%;"></div>
                </div>
                <div class="progress-percent">90%</div>
            </div>
            <div class="progress-item">
                <span>lorem</span>
                <div class="progress-bar">
                    <div class="progress-fill" style="width: 90%;"></div>
                </div>
                <div class="progress-percent">90%</div>
            </div>
            <div class="progress-item">
                <span>lorem</span>
                <div class="progress-bar">
                    <div class="progress-fill" style="width: 90%;"></div>
                </div>
                <div class="progress-percent">90%</div>
            </div>
        </div>
    
        </section>

        <!-- Certification -->

        <section class="certifications" id="certifications">
            <h2>Certifications</h2>
            <div class="certifications-container">
                <ul>
                    <li>lorem</li>
                    <li>lorem</li>
                    <li>loreme</li>
                    <li>lorem</li>
                    <li>lorem</li>
                    <li>lorem</li>
                    <li>lorem</li>
                </ul>
            </div>
        </section>
    
        <!-- Contact -->

        <section class="contact" id="contact">
            <h2>Contact Me</h2>
            <p>lorem.</p>
            <form action="." method="POST" class="contact-form">
                <div class="form-group">
                    <label for="name">Name</label>
                    <input type="text" id="name" name="name" placeholder="Enter your name" required>
                </div>
                <div class="form-group">
                    <label for="email">Email</label>
                    <input type="email" id="email" name="email" placeholder="Enter your email" required>
                </div>
                <div class="form-group">
                    <label for="subject">Subject</label>
                    <input type="text" id="subject" name="subject" placeholder="Enter the subject" required>
                </div>
                <div class="form-group">
                    <label for="message">Message</label>
                    <textarea id="message" name="message" rows="5" placeholder="Write your message here" required></textarea>
                </div>
                <button type="submit" name="submit_form" class="btn">Send Message</button>
            </form>
        </section>

        <!-- Footer -->
        <footer class="footer">
            <div class="footer-container">
                <div class="social-icons">
                    <a href="https://github.com/trimaticthread" target="_blank" aria-label="GitHub">
                        <i class="bx bxl-github"></i>
                    </a>
                    <a href="https://www.linkedin.com/in/sina-toprak-gulec-26761923b/" target="_blank" aria-label="LinkedIn">
                        <i class="bx bxl-linkedin"></i>
                    </a>
                    <a href="https://www.instagram.com/toprakgulecc02/" target="_blank" aria-label="Instagram">
                        <i class="bx bxl-instagram"></i>
                    </a>
                </div>
                <nav class="footer-navbar">
                    <a href="#home">Home</a>
                    <a href="#about">About</a>
                    <a href="#skills">Skills</a>
                    <a href="#certifications">Certificates</a>
                    <a href="#contact">Contact</a>
                </nav>
                <p class="copyright">&copy; 2024 Sina Toprak Güleç | Tüm Hakları Saklıdır</p>
            </div>
        </footer>
        


        
        



     <script src="main.js"></script>
</body>
</html>